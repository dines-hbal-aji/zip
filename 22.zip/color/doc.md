# 🎨 ColorHub — Color Reservation System
### Complete Project Documentation

**Author:** 23COS212 — K. Dinesh Balaji  
**Institution:** B.Sc. Computer Science, The American College, Madurai  
**Date:** March 2026  
**Version:** 1.0

---

## Table of Contents

1. [Topic](#1-topic)
2. [Abstract](#2-abstract)
3. [Existing System](#3-existing-system)
4. [Proposed System](#4-proposed-system)
5. [Advantages](#5-advantages)
6. [Disadvantages](#6-disadvantages)
7. [Flowchart / Diagram Types](#7-flowchart--diagram-types)
8. [Modules List](#8-modules-list)
9. [Modules Explanation with Sample Output](#9-modules-explanation-with-sample-output)
10. [Hardware / Software Requirements](#10-hardware--software-requirements)
11. [Literature / Reference Papers](#11-literature--reference-papers)
12. [Bibliography](#12-bibliography)
13. [User Manual — How to Run the Code](#13-user-manual--how-to-run-the-code)

---

## 1. Topic

**ColorHub — An Online Color Reservation System with Advanced Color Combination Tools**

ColorHub is a full-stack web application designed to allow users to browse a curated catalog of paint and design colors, reserve specific colors for specific date ranges, manage bookings, submit reviews, and explore professionally generated color combinations — all managed through a secure, role-based admin dashboard backed by a RESTful Python Flask API and SQLite database.

---

## 2. Abstract

In paint manufacturing, interior design, and product customization industries, color management and reservation tracking remain largely manual or paper-based. Clients often face issues such as double-booking of exclusive color batches, no real-time availability visibility, and limited access to professional color pairing guidance.

**ColorHub** solves these problems by providing:

- A **multi-page responsive web application** built with HTML5, CSS3 (Vanilla), and JavaScript
- A **Flask REST API backend** with JWT-based authentication and SQLite persistence
- A **real-time conflict detection engine** that prevents double-booking of color reservations
- A **Color Combination Studio** with 6 professional color theory algorithms (complementary, analogous, triadic, split-complementary, tetradic, monochromatic)
- A **full Admin Dashboard** with real-time analytics, chart visualizations, inventory management, user control, and export capabilities

The system supports **two user roles** — *Customer* and *Administrator* — each with tailored features. It is fully responsive across mobile, tablet, and desktop devices and integrates gracefully with or without the backend through an offline localStorage fallback.

**Keywords:** Color Reservation, Flask REST API, JWT Authentication, Color Theory Algorithms, Role-Based Access Control, Real-Time Conflict Detection, Responsive Web Design

---

## 3. Existing System

### 3.1 Current Practice

Traditional color reservation and management systems in paint shops, interior design firms, and manufacturing units rely on:

| Method | Problems |
|--------|----------|
| Manual ledger / register entries | Error-prone, no conflict detection |
| Basic spreadsheets (Excel/Google Sheets) | No real-time access, version conflicts |
| Phone/WhatsApp bookings | No confirmation records, no date tracking |
| Generic booking software | Not color-specific, no combination tools |

### 3.2 Drawbacks of Existing Systems

1. **No conflict prevention** — Two clients can book the same color batch for overlapping dates
2. **No real-time availability** — Customers cannot check availability without calling the shop
3. **No color combination guidance** — Customers rely on trial and error or physical swatches
4. **No centralized analytics** — Admins cannot track popular colors, revenue or booking trends
5. **No mobile access** — Systems are desktop-only or non-digital
6. **No user-level history** — Customers cannot view their booking history or submit reviews
7. **No automated pricing** — Manual calculation of reservation cost leads to errors
8. **Scalability issues** — As inventory grows, manual systems become unmanageable

---

## 4. Proposed System

### 4.1 System Overview

ColorHub proposes a **web-based, API-driven color reservation platform** with the following architectural layers:

```
┌──────────────────────────────────────────────────┐
│               FRONTEND (Browser)                  │
│  index.html  catalog.html  dashboard.html         │
│  reservation.html  combinations.html  admin.html  │
│  assets/js/app.js   assets/css/styles.css         │
└──────────────┬───────────────────────────────────┘
               │ HTTP REST (JSON)
┌──────────────▼───────────────────────────────────┐
│         BACKEND (Python Flask — port 5000)        │
│  Authentication · Colors · Reservations           │
│  Reviews · Combinations · Admin · Health          │
└──────────────┬───────────────────────────────────┘
               │ SQLAlchemy ORM
┌──────────────▼───────────────────────────────────┐
│            DATABASE (SQLite — colorhub.db)        │
│  users · colors · reservations · reviews          │
│  color_combinations                               │
└──────────────────────────────────────────────────┘
```

### 4.2 Key Features of Proposed System

| Feature | Description |
|---------|-------------|
| JWT Authentication | Secure stateless login with 7-day tokens |
| Role-Based Access | Separate flows for User and Admin |
| Color Catalog | 30+ colors with search, filter, sort |
| Conflict Detection | Prevents double-booking by date-range overlap |
| Auto Pricing | Total = price × quantity × days |
| Color Combinations | 6 color theory algorithms via Python `colorsys` |
| Admin Dashboard | Live stats, 4 Chart.js charts, full management |
| Responsive Design | Mobile bottom-nav, stacked grids at all breakpoints |
| Dual-Mode Operation | API mode + localStorage offline fallback |
| Data Export | CSV/JSON export of reports from admin panel |

---

## 5. Advantages

1. **Zero Double-Bookings** — Server-side date overlap algorithm prevents any conflicting reservation at the database level
2. **Real-Time Availability** — Users see live availability before confirming; `/api/reservations/<id>/availability` endpoint returns reserved date ranges
3. **Professional Color Guidance** — 6 color theory tools built on Python's `colorsys` module (HSV rotation for analogous/triadic/tetradic, RGB inversion for complementary)
4. **Fully Responsive** — Works perfectly on phones (390px), tablets (768px), and desktops (1440px); mobile users get a bottom tab bar navigation
5. **Secure** — Werkzeug PBKDF2-SHA256 password hashing, JWT token expiry, admin-only endpoint guards
6. **Scalable** — SQLAlchemy ORM allows swapping SQLite → PostgreSQL/MySQL with zero code change
7. **Offline Capable** — localStorage fallback ensures the app works even if the Flask server is unreachable
8. **Rich Analytics** — Chart.js charts (line, doughnut, bar) give admins instant business intelligence
9. **Developer Friendly** — RESTful API with consistent `{ok, msg, data}` JSON responses; CORS-enabled for any frontend
10. **Open & Portable** — Pure HTML/CSS/JS frontend needs no build step; just open in a browser

---

## 6. Disadvantages

1. **SQLite Limitations** — SQLite is not suitable for high-concurrency production environments; concurrent writes can lock the database
2. **No Payment Gateway Integration** — Current version stores payment method and a mock transaction ID; real Razorpay/PayU integration is not yet live
3. **No Email Notifications** — Booking confirmations and cancellations are not emailed to users
4. **No Image Support** — Color swatches are rendered via CSS background (`hex_code`); no real image upload for physical color samples
5. **JWT Secret Hardcoded** — The JWT secret key is currently hardcoded in `app.py`; should be moved to environment variables in production
6. **No Pagination** — All colors, reservations, reviews are returned in a single API response; large datasets may impact performance
7. **Single-Server Architecture** — No load balancing or caching layer (Redis); not suitable for high-traffic scenarios without infrastructure changes
8. **Browser Dependency** — Requires a modern browser with ES6+ JavaScript support; no IE compatibility
9. **No SMS/Push Notifications** — No integration with SMS gateways like Twilio for booking alerts
10. **localStorage Security** — Offline mode stores JWT tokens in localStorage, which is susceptible to XSS attacks in untrusted environments

---

## 7. Flowchart / Diagram Types

### 7a. ER Diagram (Entity-Relationship)

```
┌─────────────────────┐        ┌─────────────────────────┐
│        USER         │        │          COLOR           │
├─────────────────────┤        ├─────────────────────────┤
│ PK  id (INT)        │        │ PK  id (INT)             │
│     name (STR)      │        │     name (STR)           │
│     email (STR, UQ) │        │     hex_code (STR)       │
│     password (STR)  │        │     rgb (STR)            │
│     role (STR)      │        │     category (STR)       │
│     phone (STR)     │        │     stock (INT)          │
│     bio (TEXT)      │        │     is_available (BOOL)  │
│     joined (DTIME)  │        │     popularity (INT)     │
└────────┬────────────┘        │     price (FLOAT)        │
         │ 1                   │     description (TEXT)   │
         │ makes               │     created_at (DTIME)   │
         │ *                   └────────────┬─────────────┘
┌────────▼────────────────────────────────▼─────────────┐
│                      RESERVATION                        │
├─────────────────────────────────────────────────────────┤
│ PK  id (STR)                                            │
│ FK  user_id  → users.id                                 │
│ FK  color_id → colors.id                                │
│     start_date (DATE)                                   │
│     end_date (DATE)                                     │
│     quantity (INT)                                      │
│     total (FLOAT)                                       │
│     payment_method (STR)                                │
│     txn_id (STR)                                        │
│     status (STR) [confirmed/cancelled]                  │
│     notes (TEXT)                                        │
│     created_at (DTIME)                                  │
└────────┬────────────────────────────────────────────────┘
         │ 1
         │ has
         │ *
┌────────▼────────────────────────────────────────────────┐
│                        REVIEW                            │
├──────────────────────────────────────────────────────────┤
│ PK  id (STR)                                             │
│ FK  user_id        → users.id                            │
│ FK  color_id       → colors.id                           │
│ FK  reservation_id → reservations.id                     │
│     rating (INT 1–5)                                     │
│     comment (TEXT)                                       │
│     created_at (DTIME)                                   │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│                   COLOR_COMBINATION                       │
├──────────────────────────────────────────────────────────┤
│ PK  id (STR)                                             │
│ FK  user_id  → users.id (nullable)                       │
│     name (STR)                                           │
│     colors (TEXT/JSON)  ← array of {hex, name}           │
│     combo_type (STR)                                     │
│     is_public (BOOL)                                     │
│     likes (INT)                                          │
│     created_at (DTIME)                                   │
└──────────────────────────────────────────────────────────┘
```

**Relationships:**
- `User` (1) ───< `Reservation` (*) — One user can have many reservations
- `Color` (1) ───< `Reservation` (*) — One color can have many reservations
- `Reservation` (1) ───< `Review` (0..1) — One reservation has at most one review
- `User` (1) ───< `ColorCombination` (*) — One user can save many combinations

---

### 7b. Class Diagram

```
┌──────────────────────┐   ┌────────────────────────────┐
│      User            │   │         Color              │
├──────────────────────┤   ├────────────────────────────┤
│ - id: int            │   │ - id: int                  │
│ - name: str          │   │ - name: str                │
│ - email: str         │   │ - hex_code: str            │
│ - password: str      │   │ - rgb: str                 │
│ - role: str          │   │ - category: str            │
│ - phone: str         │   │ - stock: int               │
│ - bio: str           │   │ - is_available: bool       │
│ - joined: datetime   │   │ - popularity: int          │
├──────────────────────┤   │ - price: float             │
│ + to_dict(): dict    │   │ - description: str         │
│ + check_password()   │   ├────────────────────────────┤
└──────┬───────────────┘   │ + to_dict(): dict          │
       │                   │ + avg_rating(): float      │
       │ 1..*              └─────────────┬──────────────┘
┌──────▼───────────────┐                │ 1..*
│    Reservation        │◄───────────────┘
├──────────────────────┤
│ - id: str            │
│ - user_id: int       │
│ - color_id: int      │
│ - start_date: date   │
│ - end_date: date     │
│ - quantity: int      │
│ - total: float       │
│ - status: str        │
│ - payment_method:str │
│ - txn_id: str        │
├──────────────────────┤
│ + to_dict(): dict    │
│ + cancel(): void     │
└──────┬───────────────┘
       │ 0..1
┌──────▼───────────────┐   ┌────────────────────────────┐
│      Review           │   │     ColorCombination       │
├──────────────────────┤   ├────────────────────────────┤
│ - id: str            │   │ - id: str                  │
│ - user_id: int       │   │ - user_id: int             │
│ - color_id: int      │   │ - name: str                │
│ - reservation_id:str │   │ - colors: JSON             │
│ - rating: int        │   │ - combo_type: str          │
│ - comment: str       │   │ - is_public: bool          │
├──────────────────────┤   │ - likes: int               │
│ + to_dict(): dict    │   ├────────────────────────────┤
└──────────────────────┘   │ + to_dict(): dict          │
                           │ + like(): void             │
                           └────────────────────────────┘
```

---

### 7c. Object Diagram (Sample Instance State)

```
:User                           :Color
─────────────────               ──────────────────────
id = 1                          id = 1
name = "Dinesh Balaji"          name = "Crimson Sunset"
email = "dinesh@example.com"    hex_code = "#DC143C"
role = "user"                   category = "Warm"
phone = "9876543210"            stock = 15
joined = 2026-03-04             price = 850.00
                                is_available = True
                                popularity = 82

:Reservation
──────────────────────────────
id = "RESxK9mLpQab"
user_id = 1   ───────────────► :User (above)
color_id = 1  ───────────────► :Color (above)
start_date = 2026-03-10
end_date = 2026-03-15
quantity = 2
total = 8500.00   (850 × 2 × 5 days)
status = "confirmed"
payment_method = "upi"
txn_id = "TXNabc123xyz"

:Review
──────────────────────────────
id = "REVqr7stUvwx"
user_id = 1
color_id = 1
reservation_id = "RESxK9mLpQab"
rating = 5
comment = "Perfect shade for living room wall!"
```

---

### 7d. Data Flow Diagram — Level 0 (Context Diagram)

```
                    ┌─────────────────────────────┐
                    │                             │
  ┌──────────┐      │    ColorHub System          │      ┌───────────┐
  │  Customer│─────►│   (Color Reservation        │─────►│  Admin    │
  │  (User)  │◄─────│    Web Application)         │◄─────│(Manager)  │
  └──────────┘      │                             │      └───────────┘
  - Browse colors   │  Processes:                 │  - Manage colors
  - Reserve color   │  • Authentication           │  - View all bookings
  - View bookings   │  • Reservation Logic        │  - Manage users
  - Submit reviews  │  • Conflict Detection       │  - View analytics
  - Explore combos  │  • Color Algorithms         │  - Export reports
                    │  • Analytics                │
                    └──────────────┬──────────────┘
                                   │
                    ┌──────────────▼──────────────┐
                    │    colorhub.db (SQLite)      │
                    │  users / colors /            │
                    │  reservations / reviews /    │
                    │  color_combinations          │
                    └─────────────────────────────┘
```

---

### 7e. Data Flow Diagram — Level 1

```
┌────────┐   login/register    ┌──────────────────────┐   token+user   ┌────────┐
│  User  │───────────────────►│  1.0 Authentication   │───────────────►│  User  │
└────────┘                    └──────────┬───────────┘                └────────┘
                                         │ read/write
                              ┌──────────▼───────────┐
                              │     D1: users         │
                              └───────────────────────┘

┌────────┐   search/filter     ┌──────────────────────┐   color list   ┌────────┐
│  User  │───────────────────►│  2.0 Color Catalog    │───────────────►│  User  │
└────────┘                    └──────────┬───────────┘                └────────┘
                                         │ read
                              ┌──────────▼───────────┐
                              │     D2: colors        │
                              └───────────────────────┘

┌────────┐   date+quantity     ┌──────────────────────┐  confirmed/err  ┌────────┐
│  User  │───────────────────►│  3.0 Reservation Eng. │───────────────►│  User  │
└────────┘                    └──────────┬───────────┘                └────────┘
                                         │ read/write
                              ┌──────────▼───────────┐
                              │  D3: reservations     │
                              └───────────────────────┘

┌────────┐   rating+comment    ┌──────────────────────┐  review saved  ┌────────┐
│  User  │───────────────────►│  4.0 Review System    │───────────────►│  User  │
└────────┘                    └──────────┬───────────┘                └────────┘
                                         │ read/write
                              ┌──────────▼───────────┐
                              │     D4: reviews       │
                              └───────────────────────┘

┌────────┐     hex color       ┌──────────────────────┐  palette set   ┌────────┐
│  User  │───────────────────►│  5.0 Color Algorithm  │───────────────►│  User  │
└────────┘                    └──────────┬───────────┘                └────────┘
                                         │ save/read
                              ┌──────────▼───────────┐
                              │  D5: combinations     │
                              └───────────────────────┘

┌────────┐   admin request     ┌──────────────────────┐   stats+data   ┌─────────┐
│ Admin  │───────────────────►│  6.0 Admin Module     │───────────────►│  Admin  │
└────────┘                    └──────────┬───────────┘                └─────────┘
                                         │ read all stores
                              ┌──────────▼───────────┐
                              │  D1+D2+D3+D4+D5       │
                              └───────────────────────┘
```

---

### 7f. Data Flow Diagram — Level 2 (Reservation Engine Expanded)

```
                         ┌─────────────────────────────────────────┐
                         │        3.0 Reservation Engine            │
                         │                                          │
  colorId, dates ───────►│  3.1 Validate Input                     │
  quantity               │   • Check required fields               │
                         │   • Parse ISO date strings              │
                         │   • Confirm end > start                 │
                         └──────────────────┬──────────────────────┘
                                            │ valid input
                         ┌──────────────────▼──────────────────────┐
                         │  3.2 Fetch Color Record                  │
                         │   • Query D2:colors by color_id          │
                         │   • Check is_available = True            │
                         └──────────────────┬──────────────────────┘
                                            │ available color
                         ┌──────────────────▼──────────────────────┐
                         │  3.3 Conflict Detection                   │
                         │   • Query D3:reservations                │
                         │     WHERE color_id = X                   │
                         │     AND status != 'cancelled'            │
                         │   • For each: check overlap              │
                         │     NOT (end <= res.start OR             │
                         │          start >= res.end)               │
                         └──────────────────┬──────────────────────┘
                                  ┌─────────┴──────────┐
                              conflict?              no conflict
                              │                          │
                    ┌─────────▼─────────┐   ┌───────────▼──────────────┐
                    │  3.4 Return Error  │   │  3.5 Calculate & Store   │
                    │  "Color already   │   │   total = price×qty×days  │
                    │   reserved for    │   │   txn_id = gen_id()       │
                    │   these dates"    │   │   INSERT reservations     │
                    └───────────────────┘   │   status = 'confirmed'   │
                                            └───────────┬──────────────┘
                                                        │
                                            ┌───────────▼──────────────┐
                                            │  3.6 Response            │
                                            │   Return reservation obj  │
                                            │   {id, total, txn_id,    │
                                            │    status: confirmed}     │
                                            └──────────────────────────┘
```

---

### 7g. Use Case Diagram

```
                         ╔══════════════════════════════════════╗
                         ║         ColorHub System              ║
                         ║                                      ║
  ┌──────────┐           ║  ○ Register / Login                  ║
  │          │────────────╫─►○ Browse Color Catalog             ║
  │  Customer│           ║  ○ Search / Filter Colors            ║
  │  (User)  │────────────╫─►○ View Color Details               ║
  │          │           ║  ○ Check Availability                ║
  └──────────┘           ║  ○ Reserve a Color ──────────────── ╫─extends──►○ Conflict Check
                         ║  ○ View My Reservations              ║
  ┌──────────┐           ║  ○ Cancel Reservation                ║
  │  Guest   │────────────╫─►○ Explore Color Combinations       ║
  │(Visitor) │           ║  ○ Use Combination Generator         ║
  └──────────┘           ║  ○ Submit Review ──────────────────  ╫─includes─►○ Verify Booking
                         ║  ○ Like Community Palettes           ║
  ┌──────────┐           ║  ○ Save Custom Palette               ║
  │  Admin   │           ║                                      ║
  │(Manager) │────────────╫─►○ Admin Login (role check)         ║
  │          │           ║  ○ View Analytics Dashboard          ║
  └──────────┘           ║  ○ Manage Color Inventory            ║
       │                 ║  ○ Add / Edit / Delete Color         ║
       │ extends         ║  ○ View All Reservations             ║
  ┌────┘                 ║  ○ Change Reservation Status         ║
  │  (inherits           ║  ○ Manage Users / Roles              ║
  │   all User           ║  ○ View All Reviews                  ║
  │   use cases)         ║  ○ Delete Reviews                    ║
                         ║  ○ View Reports                      ║
                         ║  ○ Export CSV / JSON                 ║
                         ║  ○ Seed Demo Data                    ║
                         ╚══════════════════════════════════════╝
```

---

## 8. Modules List

| # | Module Name | Page / File | Description |
|---|------------|-------------|-------------|
| 1 | **Authentication Module** | `index.html`, `app.js` | User registration, login, logout, JWT management |
| 2 | **Color Catalog Module** | `catalog.html` | Browse, search, filter, sort colors |
| 3 | **Reservation Module** | `reservation.html` | Book colors, conflict detection, pricing |
| 4 | **User Dashboard Module** | `dashboard.html` | View bookings, profile, reviews, stats |
| 5 | **Color Combination Module** | `combinations.html` | 6 algo tools, custom builder, community, blend |
| 6 | **Admin Analytics Module** | `admin.html` | Live stats, Chart.js charts, top colors |
| 7 | **Admin Color Management** | `admin.html` | Add, edit, delete, search colors |
| 8 | **Admin Reservation Management** | `admin.html` | View/cancel all reservations, table view |
| 9 | **Admin User Management** | `admin.html` | List users, change roles, delete users |
| 10 | **Admin Review Management** | `admin.html` | View/delete all community reviews |
| 11 | **Admin Reports & Export** | `admin.html` | Revenue summary, CSV/JSON export, print |
| 12 | **REST API Backend** | `backend/app.py` | 30+ endpoints, JWT guard, conflict engine |
| 13 | **Color Algorithm Engine** | `backend/app.py` | 6 HSV/RGB color theory algorithms |
| 14 | **Database Layer** | `backend/colorhub.db` | SQLite + SQLAlchemy ORM, 5 tables |

---

## 9. Modules Explanation with Sample Output

---

### Module 1 — Authentication Module

**Files:** `index.html`, `assets/js/app.js`  
**Backend:** `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`

**Description:**  
Handles user registration and login. On success, the backend returns a JWT token (7-day expiry) which is stored in `localStorage`. Every subsequent API call includes this token in the `Authorization: Bearer <token>` header. The `Auth` object in `app.js` manages the full auth lifecycle.

**Flow:**
```
User fills email + password
        │
        ▼
POST /api/auth/login
        │
        ▼
Werkzeug password hash check
        │
      pass? ──No──► Return 401 {ok:false, msg:"Invalid credentials"}
        │
      Yes
        │
        ▼
JWT token generated (HS256, 7 days)
        │
        ▼
Response: {ok:true, token:"eyJ...", user:{id,name,email,role}}
        │
        ▼
Frontend: localStorage.setItem('jwt_token', token)
Frontend: Redirect to dashboard / reload page
```

**Sample API Response:**
```json
POST /api/auth/login
Body: {"email": "admin@colorhub.com", "password": "admin123"}

Response 200:
{
  "ok": true,
  "msg": "Logged in!",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": 1,
      "name": "Admin",
      "email": "admin@colorhub.com",
      "role": "admin",
      "phone": "9876543210",
      "joined": "2026-03-04T16:42:05.327443"
    }
  }
}
```

---

### Module 2 — Color Catalog Module

**File:** `catalog.html`  
**Backend:** `GET /api/colors`

**Description:**  
Displays all 30+ colors as an interactive card grid. Users can search by name/hex, filter by category (Warm, Cool, Nature, Luxury, Neutral), sort by popularity/price/name, and filter by availability. Each card shows a color swatch, name, hex, category, price, stock, rating, and a "Reserve" button.

**Sample API Response:**
```json
GET /api/colors?category=Warm&sort=price-asc&available=true

Response 200:
{
  "ok": true,
  "data": [
    {
      "id": 14,
      "name": "Arctic White",
      "hex": "#F0F4F8",
      "category": "Warm",
      "stock": 50,
      "available": true,
      "popularity": 71,
      "price": 450.0,
      "avgRating": 4.2,
      "reviewCount": 3,
      "reservationCount": 1
    },
    ...
  ]
}
```

**Sample UI Output:**
```
┌─────────────────────────────────────────────────────────────────┐
│  🔍  Search colors...    [Category ▾]  [Sort ▾]  [☑ Available]  │
├─────────────┬─────────────┬─────────────┬─────────────┐        │
│ ████████████│ ████████████│ ████████████│ ████████████│        │
│ Crimson     │ Golden      │ Coral Kiss  │ Tangerine   │        │
│ Sunset      │ Harvest     │             │ Bliss       │        │
│ #DC143C     │ #F0A500     │ #FF6B6B     │ #FF8C00     │        │
│ Warm ★4.5   │ Warm ★3.8   │ Warm ★5.0   │ Warm ★4.1   │        │
│ ₹850  [Rsv] │ ₹750  [Rsv] │ ₹890  [Rsv] │ ₹720  [Rsv] │        │
└─────────────┴─────────────┴─────────────┴─────────────┘        │
└─────────────────────────────────────────────────────────────────┘
```

---

### Module 3 — Reservation Module

**File:** `reservation.html`  
**Backend:** `POST /api/reservations`, `GET /api/reservations/<id>/availability`

**Description:**  
The most critical module. Users select a color, start date, end date, quantity, payment method, and notes. The system calculates the total cost (`price × quantity × days`) and runs a conflict detection check. If no overlap with existing active reservations, the booking is confirmed and a unique transaction ID is generated.

**Pricing Formula:**
```
Total = Color Price (₹) × Quantity × Duration (days)

Example:
  Color: Crimson Sunset — ₹850/unit
  Quantity: 2
  Duration: 5 days (Mar 10 → Mar 15)
  Total = 850 × 2 × 5 = ₹8,500
```

**Conflict Detection Algorithm:**
```python
def check_conflict(color_id, start_date, end_date):
    active = Reservation.query.filter(
        color_id == color_id,
        status   != 'cancelled'
    ).all()
    for r in active:
        if not (end_date <= r.start_date or start_date >= r.end_date):
            return True   # CONFLICT!
    return False
```

**Sample Response (Conflict):**
```json
{
  "ok": false,
  "msg": "Color already reserved for these dates. Please choose different dates."
}
```

**Sample Response (Success):**
```json
{
  "ok": true,
  "msg": "Reservation confirmed!",
  "data": {
    "id": "RESxK9mLpQab",
    "colorName": "Crimson Sunset",
    "colorHex": "#DC143C",
    "startDate": "2026-03-10",
    "endDate": "2026-03-15",
    "quantity": 2,
    "total": 8500.0,
    "txnId": "TXNabc123xyz",
    "status": "confirmed"
  }
}
```

---

### Module 4 — User Dashboard Module

**File:** `dashboard.html`  
**Backend:** `GET /api/reservations`, `PUT /api/auth/profile`

**Description:**  
A personalized portal showing the logged-in user's statistics (total bookings, active reservations, total spent, average rating given), full booking history table, and profile editor. Users can update their name, phone, bio, and password.

**Sample Dashboard Stats Display:**
```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│   📅          │   ✅          │   ₹           │   ⭐          │
│   3           │   2           │   21,500      │   4.7         │
│ Total Bookings│ Active Res.  │ Total Spent   │ Avg Rating   │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

---

### Module 5 — Color Combination Module

**File:** `combinations.html`  
**Backend:** `POST /api/combinations/generate`, `GET /api/combinations`, `POST /api/combinations`

**Description:**  
A rich 5-tab studio offering professional color theory tools:

| Tab | Tool | Algorithm |
|-----|------|-----------|
| Generator | Scheme from any hex | HSV rotation via Python `colorsys` |
| Custom Builder | Up to 8 colors | Manual hex picker + save to community |
| All Combos | Catalog × schemes | Cross product of all 30 colors × 6 schemes |
| Community | Browse palettes | Fetch from DB, like with POST /like |
| Blend | Gradient blending | Linear interpolation between two hex colors |

**Algorithm Details (Python):**
```python
# Complementary — RGB inversion
comp = rgb_to_hex(255-r, 255-g, 255-b)

# Analogous — ±30° hue rotation
h2 = (h ± 1/12) % 1.0  →  hsv_to_rgb → hex

# Triadic — 120° hue spacing
offsets = [1/3, 2/3]   →  hsv_to_rgb → hex

# Tetradic — 90° square spacing
offsets = [1/4, 1/2, 3/4]  →  hsv_to_rgb → hex

# Monochromatic — 3 brightness levels
v in [0.3, 0.55, 0.8]  →  hsv_to_rgb → hex
```

**Sample API Response:**
```json
POST /api/combinations/generate
Body: {"hex": "#DC143C"}

Response:
{
  "data": {
    "input": "#DC143C",
    "complementary": {"colors": ["#DC143C", "#23EBC3"]},
    "analogous":     {"colors": ["#DC6814", "#DC143C", "#DC1468"]},
    "triadic":       {"colors": ["#DC143C", "#3CDC14", "#143CDC"]},
    "monochromatic": {"colors": ["#4D0000", "#8F0A22", "#DC143C"]}
  }
}
```

---

### Module 6 — Admin Analytics Module

**File:** `admin.html`  
**Backend:** `GET /api/admin/stats`

**Description:**  
The Overview & Charts panel shows 4 live stat cards and 4 Chart.js charts.

| Chart | Type | Data Source |
|-------|------|-------------|
| Reservations Over Time | Line | Monthly reservation counts |
| Popular Categories | Doughnut | Reservations per category |
| Revenue Split | Doughnut | Revenue by payment method |
| Rating Distribution | Horizontal Bar | Count of 1★–5★ reviews |

**Sample Stats Response:**
```json
GET /api/admin/stats
Authorization: Bearer <admin_token>

{
  "data": {
    "totalColors": 30,
    "totalReservations": 0,
    "confirmedRes": 0,
    "cancelledRes": 0,
    "totalRevenue": 0.0,
    "totalUsers": 1,
    "totalReviews": 0,
    "totalCombinations": 0
  }
}
```

---

### Module 7 — Admin Color Management

**Backend:** `POST /api/colors`, `PUT /api/colors/<id>`, `DELETE /api/colors/<id>`

Users with the `admin` role can:
- Add new colors (name, hex picker, category, price, stock, description)
- Edit existing stock quantities via prompt
- Delete colors from the catalog
- Search the color inventory in real-time

---

### Module 8 — Admin Reservation Management

**Backend:** `GET /api/reservations` (admin token), `PUT /api/reservations/<id>/cancel`

Shows all reservations system-wide in a scrollable table with Color, User, Dates, Amount, Status columns. Admins can cancel any reservation.

---

### Module 9 — Admin User Management

**Backend:** `GET /api/admin/users`, `PUT /api/admin/users/<id>`, `DELETE /api/admin/users/<id>`

Lists all registered users with their reservation count. Admins can promote/demote roles and delete accounts (except their own).

---

### Module 10 — Admin Review Management

**Backend:** `GET /api/admin/reviews`, `DELETE /api/reviews/<id>`

Displays all community reviews. Admins can moderate and delete inappropriate reviews.

---

### Module 11 — Admin Reports & Export

Generates revenue summaries, reservation breakdowns, and supports:
- **Export CSV** — Downloads all reservations as a `.csv` file
- **Export JSON** — Downloads full data as `.json`
- **Print Report** — Browser `window.print()` for paper/PDF

---

### Module 12 — REST API Backend

**File:** `backend/app.py`  
**Framework:** Python Flask 3.x

**Complete Endpoint Reference:**

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/health` | None | Server health check |
| POST | `/api/auth/register` | None | Create account |
| POST | `/api/auth/login` | None | Login, get JWT |
| GET | `/api/auth/me` | JWT | Get current user |
| PUT | `/api/auth/profile` | JWT | Update profile |
| GET | `/api/colors` | None | List colors (search/filter) |
| GET | `/api/colors/<id>` | None | Single color |
| POST | `/api/colors` | Admin | Add color |
| PUT | `/api/colors/<id>` | Admin | Update color |
| DELETE | `/api/colors/<id>` | Admin | Delete color |
| GET | `/api/colors/<id>/combinations` | None | Get color schemes |
| GET | `/api/reservations` | JWT | User's reservations |
| POST | `/api/reservations` | JWT | Create reservation |
| GET | `/api/reservations/<id>` | JWT | Get one reservation |
| PUT | `/api/reservations/<id>/cancel` | JWT | Cancel reservation |
| GET | `/api/reservations/<cid>/availability` | None | Check availability |
| GET | `/api/reviews` | None | Get reviews |
| POST | `/api/reviews` | JWT | Add review |
| DELETE | `/api/reviews/<id>` | Admin | Delete review |
| GET | `/api/combinations` | None | Public combinations |
| GET | `/api/combinations/my` | JWT | My combinations |
| POST | `/api/combinations` | JWT (opt) | Save combination |
| POST | `/api/combinations/generate` | None | Generate scheme |
| POST | `/api/combinations/<id>/like` | None | Like combination |
| DELETE | `/api/combinations/<id>` | JWT | Delete combination |
| GET | `/api/admin/stats` | Admin | Dashboard stats |
| GET | `/api/admin/users` | Admin | All users |
| PUT | `/api/admin/users/<id>` | Admin | Update user role |
| DELETE | `/api/admin/users/<id>` | Admin | Delete user |
| GET | `/api/admin/reviews` | Admin | All reviews |

---

### Module 13 — Color Algorithm Engine

**File:** `backend/app.py` (Lines 182–239)  
**Library:** Python `colorsys` (standard library)

| Scheme | Algorithm | Colors Produced |
|--------|-----------|----------------|
| Complementary | RGB inversion: `255-r, 255-g, 255-b` | 1 color |
| Analogous | HSV hue ±30° (±1/12) | 2 colors |
| Triadic | HSV hue +120°, +240° (1/3, 2/3) | 2 colors |
| Split-Complementary | HSV hue +150°, +210° (5/12, 7/12) | 2 colors |
| Tetradic | HSV hue +90°, +180°, +270° (1/4, 1/2, 3/4) | 3 colors |
| Monochromatic | Fixed hue/saturation, V∈{0.3, 0.55, 0.8} | 3 shades |

---

### Module 14 — Database Layer

**File:** `backend/colorhub.db` (SQLite)  
**ORM:** Flask-SQLAlchemy

Initial seeded data on first run:
- **1 Admin user** — `admin@colorhub.com` / `admin123`
- **30 Colors** — Covering all 5 categories with prices ₹450–₹1,350

---

## 10. Hardware / Software Requirements

### 10.1 Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | Intel Core i3 / AMD Ryzen 3 | Intel Core i5+ |
| RAM | 2 GB | 4 GB+ |
| Storage | 100 MB free | 500 MB+ free |
| Network | Any internet connection | Broadband (1 Mbps+) |
| Display | 1024×768 | 1920×1080 |
| Input | Keyboard + Mouse | Keyboard + Mouse + Touch |

### 10.2 Software Requirements

#### Server Side (Backend)
| Software | Version | Purpose |
|----------|---------|---------|
| Python | 3.9+ | Backend runtime |
| Flask | 3.0.0 | Web framework |
| Flask-CORS | 4.0.0 | Cross-origin requests |
| Flask-JWT-Extended | 4.6.0 | JWT authentication |
| Flask-SQLAlchemy | 3.1.1 | ORM |
| Werkzeug | 3.0.1 | Password hashing |
| SQLite3 | Built-in | Database |
| Python-dotenv | 1.0.0 | Environment variables |

#### Client Side (Frontend)
| Software | Version | Purpose |
|----------|---------|---------|
| HTML5 | Latest | Page structure |
| CSS3 | Latest | Styling / animations |
| JavaScript (ES6+) | Latest | Application logic |
| Chart.js | 4.4.0 (CDN) | Analytics charts |
| Google Fonts | Outfit, Inter | Typography |

#### Development Tools
| Tool | Purpose |
|------|---------|
| Visual Studio Code | Code editing |
| Chrome / Firefox | Browser testing |
| Postman / curl | API testing |
| Git | Version control |
| PowerShell / Terminal | Running commands |

#### Supported Browsers
| Browser | Minimum Version |
|---------|----------------|
| Google Chrome | 90+ |
| Mozilla Firefox | 88+ |
| Microsoft Edge | 90+ |
| Safari | 14+ |

---

## 11. Literature / Reference Papers

1. **Fielding, R.T. (2000).** — *Architectural Styles and the Design of Network-based Software Architectures.* University of California, Irvine. [REST Dissertation — core principles of REST API design used in this project]

2. **Grinberg, M. (2018).** — *Flask Web Development: Developing Web Applications with Python (2nd Ed.).* O'Reilly Media. ISBN: 978-1491991732 [Flask framework reference for routes, ORM, JWT integration]

3. **Itten, J. (1961).** — *The Art of Color: The Subjective Experience and Objective Rationale of Color.* Van Nostrand Reinhold. [Foundation of all 6 color harmony algorithms — complementary, analogous, triadic, tetradic, monochromatic]

4. **Albers, J. (1963).** — *Interaction of Color.* Yale University Press. [Color perception theory underlying the Combination Studio tools]

5. **RFC 7519 (2015).** — *JSON Web Tokens (JWT).* IETF / Internet Engineering Task Force. [Standard specification for the JWT authentication system implemented]

6. **Codd, E.F. (1970).** — *A Relational Model of Data for Large Shared Data Banks.* Communications of the ACM, 13(6), 377–387. [Relational database design principles used in the 5-table schema]

7. **W3C (2021).** — *CSS Color Module Level 4.* World Wide Web Consortium. [CSS color model reference for HEX/RGB color rendering]

8. **OWASP (2023).** — *OWASP Top 10 Web Application Security Risks.* Open Web Application Security Project. [Security best practices: password hashing, JWT storage, input validation]

9. **Booth, K., & Wyvill, G. (1982).** — *Data Structures for Computer Graphics.* [HSV color model computation reference for colorsys-based algorithm]

10. **Nielsen, J. (1994).** — *Usability Engineering.* Academic Press. ISBN: 0-12-518406-9. [UX principles applied in the mobile-first responsive design and navigation patterns]

---

## 12. Bibliography

1. Flask Documentation. (2024). *Flask — A lightweight WSGI web application framework.* Retrieved from https://flask.palletsprojects.com/

2. Flask-SQLAlchemy Documentation. (2024). Retrieved from https://flask-sqlalchemy.palletsprojects.com/

3. Flask-JWT-Extended Documentation. (2024). Retrieved from https://flask-jwt-extended.readthedocs.io/

4. Chart.js Documentation. (2024). *Chart.js — Simple, flexible JavaScript charts.* Retrieved from https://www.chartjs.org/docs/

5. SQLite Documentation. (2024). *SQLite — A C-language library that implements a small, fast, self-contained SQL database engine.* Retrieved from https://www.sqlite.org/docs.html

6. Python `colorsys` Module. (2024). *Python Standard Library — colorsys.* Retrieved from https://docs.python.org/3/library/colorsys.html

7. MDN Web Docs. (2024). *JavaScript Reference — Fetch API, Async/Await, LocalStorage.* Retrieved from https://developer.mozilla.org/

8. Werkzeug Documentation. (2024). *werkzeug.security — Password Hashing.* Retrieved from https://werkzeug.palletsprojects.com/en/latest/utils/#module-werkzeug.security

9. CORS — Cross-Origin Resource Sharing. (2024). *MDN Web Docs.* Retrieved from https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS

10. Google Fonts. (2024). *Outfit & Inter typefaces.* Retrieved from https://fonts.google.com/

11. GitHub — Flask-CORS. (2024). Retrieved from https://github.com/corydolphin/flask-cors

12. W3Schools. (2024). *HTML5 / CSS3 Reference.* Retrieved from https://www.w3schools.com/

---

## 13. User Manual — How to Run the Code

### Prerequisites

Ensure the following are installed on your system:
- **Python 3.9 or higher** — Download from https://python.org/downloads/
- **pip** (comes with Python)
- A modern web browser (Chrome, Firefox, Edge)

---

### Step 1 — Download / Clone the Project

```
Project folder structure:
color/
├── index.html
├── catalog.html
├── dashboard.html
├── reservation.html
├── combinations.html
├── admin.html
├── doc.md
├── readme.md
├── assets/
│   ├── css/
│   │   └── styles.css
│   └── js/
│       └── app.js
└── backend/
    ├── app.py
    ├── requirements.txt
    ├── colorhub.db        ← auto-created on first run
    └── start_server.bat   ← Windows quick-start script
```

---

### Step 2 — Install Python Dependencies

Open a terminal / PowerShell and navigate to the `backend` folder:

```powershell
cd "c:\Users\dines\Desktop\ex\main cos\color\backend"
pip install -r requirements.txt
```

The `requirements.txt` contains:
```
flask
flask-cors
flask-jwt-extended
flask-sqlalchemy
werkzeug
python-dotenv
```

---

### Step 3 — Start the Backend Server

**Option A — Use the batch script (Windows double-click):**
```
Double-click: backend/start_server.bat
```

**Option B — Run manually:**
```powershell
cd "c:\Users\dines\Desktop\ex\main cos\color\backend"
python app.py
```

**Expected output:**
```
✅  Database seeded — 30 colors, 1 users
🎨  ColorHub API starting on http://localhost:5000
   Admin: admin@colorhub.com / admin123

 * Running on http://0.0.0.0:5000
 * Debug mode: on
```

> **Note:** The database (`colorhub.db`) is **auto-created** on first run with 30 seed colors and 1 admin account. You do NOT need to run any SQL scripts manually.

---

### Step 4 — Open the Frontend

Open any of the HTML files directly in your browser:

```
Method 1 — Double-click index.html in File Explorer

Method 2 — Open in Chrome via address bar:
  file:///C:/Users/dines/Desktop/ex/main%20cos/color/index.html
```

> The app detects whether the backend is running and shows a status badge (🟢 Live API / 🟡 Offline Mode).

---

### Step 5 — Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@colorhub.com` | `admin123` |
| Demo User | Register a new account | Any password (min 6 chars) |

---

### Step 6 — Navigate the Application

| Page | URL / File | Access |
|------|-----------|--------|
| Home / Landing | `index.html` | Public |
| Color Catalog | `catalog.html` | Public |
| Color Combinations | `combinations.html` | Public |
| Reservation | `reservation.html` | Login required |
| User Dashboard | `dashboard.html` | Login required |
| Admin Panel | `admin.html` | Admin role required |

---

### Step 7 — Test the API Directly (Optional)

Open PowerShell and test the health endpoint:

```powershell
Invoke-WebRequest -Uri "http://localhost:5000/api/health" -UseBasicParsing | Select-Object -ExpandProperty Content
```

Expected:
```json
{"data":{"colors":30,"reservations":0,"status":"ok","users":1,"version":"1.0"},"msg":"","ok":true}
```

Test login:
```powershell
Invoke-WebRequest -Uri "http://localhost:5000/api/auth/login" `
  -Method POST -ContentType "application/json" `
  -Body '{"email":"admin@colorhub.com","password":"admin123"}' `
  -UseBasicParsing | Select-Object -ExpandProperty Content
```

---

### Step 8 — Making a Reservation (End-to-End Walkthrough)

1. Open `catalog.html` → Browse colors
2. Click **"Reserve"** on any color card
3. You will be redirected to `reservation.html?color=<id>`
4. If not logged in → Login modal appears → Enter credentials
5. Select **Start Date** and **End Date**
6. Enter **Quantity** (number of units)
7. Choose **Payment Method** (UPI / Card / Net Banking / Cash)
8. Click **"Confirm Reservation"**
9. ✅ Success toast appears with Reservation ID and Transaction ID
10. Go to `dashboard.html` to see your booking in the history table

---

### Step 9 — Admin Panel Usage

1. Open `admin.html`
2. Click **"Admin Login"**
3. Enter `admin@colorhub.com` / `admin123`
4. Dashboard loads with:
   - **Overview & Charts** — Live stats + 4 charts
   - **Color Inventory** — Search, add, edit stock
   - **All Reservations** — View/cancel all bookings
   - **User Management** — Change roles, delete users
   - **Reviews** — Moderate community reviews
   - **Reports** — Summary + CSV/JSON export
   - **Settings** — Platform config + danger zone

---

### Common Troubleshooting

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again |
| Port 5000 already in use | Change `port=5000` to `port=5001` in `app.py` |
| `colorhub.db` locked | Close all SQLite browser tools; restart `app.py` |
| Login shows "Invalid credentials" | Ensure backend is running; check backend console for errors |
| 🟡 Offline Mode badge | Backend is not running; start `python app.py` in backend folder |
| Charts not showing | Ensure internet connection (Chart.js loads from CDN) |
| Admin login says "Not Admin" | Ensure you're using `admin@colorhub.com` (not a regular user account) |

---

### API Base URL

```
http://localhost:5000
```

All API endpoints follow the pattern:
```
http://localhost:5000/api/<resource>
```

---

*End of Documentation*

---


