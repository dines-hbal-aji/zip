// ====================================================
//  ColorHub — API Client + App Logic
//  Connects to Flask backend (localhost:5000)
//  Falls back to localStorage if offline
// ====================================================

const API_BASE = 'http://localhost:5000/api';
let IS_ONLINE = false; // will be detected on load

// ── API Helper ─────────────────────────────────────────────
const API = {
  token: () => localStorage.getItem('crs_token'),

  headers() {
    const h = { 'Content-Type': 'application/json' };
    const t = this.token();
    if (t) h['Authorization'] = `Bearer ${t}`;
    return h;
  },

  async request(method, path, body = null) {
    try {
      const opts = { method, headers: this.headers() };
      if (body) opts.body = JSON.stringify(body);
      const res = await fetch(API_BASE + path, opts);
      const json = await res.json();
      if (!res.ok && res.status === 401) { Auth.logout(); return { ok: false, msg: 'Session expired' }; }
      return json;
    } catch (e) {
      return { ok: false, msg: 'Cannot reach server — using local data', offline: true };
    }
  },

  get: (path)        => API.request('GET',    path),
  post: (path, body) => API.request('POST',   path, body),
  put: (path, body)  => API.request('PUT',    path, body),
  del: (path)        => API.request('DELETE', path),
};

// ── Local Data Store (fallback) ────────────────────────────
const CRS = {
  currentUser: null,
  users:        JSON.parse(localStorage.getItem('crs_users')        || '[]'),
  reservations: JSON.parse(localStorage.getItem('crs_reservations') || '[]'),
  reviews:      JSON.parse(localStorage.getItem('crs_reviews')      || '[]'),
  combinations: JSON.parse(localStorage.getItem('crs_combinations') || '[]'),

  colors: [
    {id:1,name:'Crimson Sunset',hex:'#DC143C',rgb:'220,20,60',category:'Warm',stock:15,available:true,popularity:92,price:850,description:'A rich, passionate crimson that evokes warmth and energy.'},
    {id:2,name:'Ocean Depth',hex:'#006994',rgb:'0,105,148',category:'Cool',stock:20,available:true,popularity:88,price:720,description:'Deep oceanic blue that brings calm and sophistication.'},
    {id:3,name:'Forest Canopy',hex:'#228B22',rgb:'34,139,34',category:'Nature',stock:18,available:true,popularity:75,price:680,description:'Lush forest green that connects you with nature.'},
    {id:4,name:'Royal Amethyst',hex:'#9B59B6',rgb:'155,89,182',category:'Luxury',stock:12,available:true,popularity:95,price:1200,description:'Majestic purple with royal heritage and elegance.'},
    {id:5,name:'Golden Harvest',hex:'#F0A500',rgb:'240,165,0',category:'Warm',stock:25,available:true,popularity:82,price:750,description:'Warm golden yellow that radiates positivity.'},
    {id:6,name:'Coral Kiss',hex:'#FF6B6B',rgb:'255,107,107',category:'Warm',stock:10,available:true,popularity:89,price:890,description:'Vibrant coral that adds playful warmth.'},
    {id:7,name:'Midnight Navy',hex:'#1B2A4A',rgb:'27,42,74',category:'Cool',stock:30,available:true,popularity:78,price:640,description:'Deep navy that conveys authority.'},
    {id:8,name:'Mint Breeze',hex:'#98D8C8',rgb:'152,216,200',category:'Cool',stock:22,available:true,popularity:70,price:590,description:'Refreshing mint for serene atmospheres.'},
    {id:9,name:'Burnt Sienna',hex:'#E97451',rgb:'233,116,81',category:'Warm',stock:16,available:true,popularity:84,price:780,description:'Earthy terracotta that grounds any room.'},
    {id:10,name:'Electric Teal',hex:'#00CED1',rgb:'0,206,209',category:'Cool',stock:8,available:true,popularity:91,price:1050,description:'Vivid teal that energizes spaces.'},
    {id:11,name:'Lavender Dreams',hex:'#B57BEE',rgb:'181,123,238',category:'Luxury',stock:14,available:true,popularity:86,price:950,description:'Soft lavender that calms and elevates.'},
    {id:12,name:'Charcoal Storm',hex:'#36454F',rgb:'54,69,79',category:'Neutral',stock:35,available:true,popularity:72,price:520,description:'Sophisticated charcoal for dramatic interiors.'},
    {id:13,name:'Tangerine Bliss',hex:'#FF8C00',rgb:'255,140,0',category:'Warm',stock:20,available:true,popularity:79,price:720,description:'Vivid orange for cheerfulness.'},
    {id:14,name:'Arctic White',hex:'#F0F4F8',rgb:'240,244,248',category:'Neutral',stock:50,available:true,popularity:65,price:450,description:'Clean crisp white for brightness.'},
    {id:15,name:'Deep Espresso',hex:'#3B1F10',rgb:'59,31,16',category:'Warm',stock:28,available:true,popularity:68,price:580,description:'Rich coffee-brown for cozy atmospheres.'},
    {id:16,name:'Hot Magenta',hex:'#FF1493',rgb:'255,20,147',category:'Luxury',stock:6,available:true,popularity:94,price:1350,description:'Bold magenta that makes a statement.'},
    {id:17,name:'Sage Whisper',hex:'#87A96B',rgb:'135,169,107',category:'Nature',stock:24,available:true,popularity:77,price:660,description:'Muted sage green for natural environments.'},
    {id:18,name:'Cobalt Dream',hex:'#0047AB',rgb:'0,71,171',category:'Cool',stock:19,available:true,popularity:85,price:810,description:'Bold cobalt for dynamic focal points.'},
    {id:19,name:'Rose Gold',hex:'#B76E79',rgb:'183,110,121',category:'Luxury',stock:11,available:true,popularity:93,price:1150,description:'Elegant rose gold for modern luxury.'},
    {id:20,name:'Lime Zest',hex:'#BEF264',rgb:'190,242,100',category:'Nature',stock:17,available:true,popularity:73,price:620,description:'Energetic lime that refreshes spaces.'},
    {id:21,name:'Slate Blue',hex:'#6A5ACD',rgb:'106,90,205',category:'Cool',stock:13,available:true,popularity:80,price:880,description:'Rich slate blue with depth.'},
    {id:22,name:'Peach Fuzz',hex:'#FFCBA4',rgb:'255,203,164',category:'Warm',stock:21,available:true,popularity:71,price:560,description:'Soft gentle peach warmth.'},
    {id:23,name:'Emerald Isle',hex:'#009473',rgb:'0,148,115',category:'Nature',stock:15,available:true,popularity:76,price:740,description:'Deep emerald for bold nature vibes.'},
    {id:24,name:'Storm Grey',hex:'#708090',rgb:'112,128,144',category:'Neutral',stock:40,available:true,popularity:66,price:490,description:'Balanced storm grey elegance.'},
    {id:25,name:'Vivid Violet',hex:'#7F00FF',rgb:'127,0,255',category:'Luxury',stock:9,available:true,popularity:90,price:1100,description:'Electric violet for bold statements.'},
    {id:26,name:'Cherry Blossom',hex:'#FFB7C5',rgb:'255,183,197',category:'Warm',stock:26,available:true,popularity:74,price:610,description:'Soft cherry pink charm.'},
    {id:27,name:'Copper Glow',hex:'#B87333',rgb:'184,115,51',category:'Warm',stock:14,available:true,popularity:81,price:830,description:'Warm copper metallic tone.'},
    {id:28,name:'Sky Clarity',hex:'#87CEEB',rgb:'135,206,235',category:'Cool',stock:30,available:true,popularity:69,price:520,description:'Light airy sky blue.'},
    {id:29,name:'Jungle Green',hex:'#29AB87',rgb:'41,171,135',category:'Nature',stock:17,available:true,popularity:77,price:690,description:'Lush tropical jungle green.'},
    {id:30,name:'Merlot Red',hex:'#73343A',rgb:'115,52,58',category:'Warm',stock:10,available:true,popularity:83,price:920,description:'Deep sophisticated wine red.'},
  ],

  save() {
    localStorage.setItem('crs_users',        JSON.stringify(this.users));
    localStorage.setItem('crs_reservations', JSON.stringify(this.reservations));
    localStorage.setItem('crs_reviews',      JSON.stringify(this.reviews));
    localStorage.setItem('crs_combinations', JSON.stringify(this.combinations));
  },

  getColorById(id)    { return this.colors.find(c => c.id == id); },
  getColorReservations(colorId) { return this.reservations.filter(r => r.colorId == colorId && r.status !== 'cancelled'); },
  isColorAvailable(colorId, startDate, endDate) {
    const existing = this.getColorReservations(colorId);
    return !existing.some(r => {
      const rs=new Date(r.startDate), re=new Date(r.endDate);
      const ns=new Date(startDate),   ne=new Date(endDate);
      return !(ne<=rs || ns>=re);
    });
  },
  getColorAvgRating(colorId) {
    const rvs = this.reviews.filter(r => r.colorId == colorId);
    if (!rvs.length) return 0;
    return rvs.reduce((s,r) => s+r.rating, 0) / rvs.length;
  }
};

// Seed local admin user
if (!CRS.users.find(u => u.role === 'admin')) {
  CRS.users.push({ id:1, name:'Admin', email:'admin@colorhub.com', password:'admin123', role:'admin', phone:'9876543210', joined:new Date().toISOString() });
  CRS.save();
}

// ── Color Math ─────────────────────────────────────────────
function hexToRgb(hex) {
  const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
  return {r,g,b};
}
function rgbToHex(r,g,b) {
  return '#'+[r,g,b].map(v => Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0')).join('').toUpperCase();
}
function hexToHsl(hex) {
  let {r,g,b} = hexToRgb(hex);
  r/=255; g/=255; b/=255;
  const max=Math.max(r,g,b), min=Math.min(r,g,b), l=(max+min)/2;
  let h=0, s=0;
  if(max!==min){ const d=max-min; s=l>0.5?d/(2-max-min):d/(max+min);
    if(max===r) h=(g-b)/d+(g<b?6:0);
    else if(max===g) h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h/=6; }
  return {h:h*360, s:s*100, l:l*100};
}
function hslToHex(h,s,l) {
  h/=360; s/=100; l/=100;
  const hue2rgb=(p,q,t)=>{ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6)return p+(q-p)*6*t; if(t<1/2)return q; if(t<2/3)return p+(q-p)*(2/3-t)*6; return p; };
  let r,g,b;
  if(s===0){r=g=b=l;}else{ const q=l<0.5?l*(1+s):l+s-l*s, p=2*l-q;
    r=hue2rgb(p,q,h+1/3); g=hue2rgb(p,q,h); b=hue2rgb(p,q,h-1/3); }
  return rgbToHex(r*255,g*255,b*255);
}

const ColorMath = {
  complementary: (hex) => { const {h,s,l}=hexToHsl(hex); return hslToHex((h+180)%360,s,l); },
  analogous:     (hex) => { const {h,s,l}=hexToHsl(hex); return [hslToHex((h-30+360)%360,s,l), hslToHex((h+30)%360,s,l)]; },
  triadic:       (hex) => { const {h,s,l}=hexToHsl(hex); return [hslToHex((h+120)%360,s,l), hslToHex((h+240)%360,s,l)]; },
  splitComp:     (hex) => { const {h,s,l}=hexToHsl(hex); return [hslToHex((h+150)%360,s,l), hslToHex((h+210)%360,s,l)]; },
  tetradic:      (hex) => { const {h,s,l}=hexToHsl(hex); return [hslToHex((h+90)%360,s,l), hslToHex((h+180)%360,s,l), hslToHex((h+270)%360,s,l)]; },
  monochromatic: (hex) => { const {h,s}=hexToHsl(hex); return [hslToHex(h,s,20), hslToHex(h,s,40), hslToHex(h,s,60), hslToHex(h,s,80)]; },
  tints:         (hex) => { const {r,g,b}=hexToRgb(hex); return [1,2,3,4].map(i=>rgbToHex(r+(255-r)*i/4,g+(255-g)*i/4,b+(255-b)*i/4)); },
  shades:        (hex) => { const {r,g,b}=hexToRgb(hex); return [1,2,3,4].map(i=>rgbToHex(r*(1-i/5),g*(1-i/5),b*(1-i/5))); },
  blend:         (hex1, hex2, t=0.5) => {
    const a=hexToRgb(hex1), b=hexToRgb(hex2);
    return rgbToHex(a.r*(1-t)+b.r*t, a.g*(1-t)+b.g*t, a.b*(1-t)+b.b*t);
  },
  getLuminance:  (hex) => { const {r,g,b}=hexToRgb(hex); return 0.299*r+0.587*g+0.114*b; },
  getTextColor:  (hex) => ColorMath.getLuminance(hex) > 128 ? '#000000' : '#ffffff',
};

// ── Auth ────────────────────────────────────────────────────
const Auth = {
  async login(email, password) {
    const res = await API.post('/auth/login', { email, password });
    if (res.ok) {
      localStorage.setItem('crs_token', res.data.token);
      CRS.currentUser = res.data.user;
      sessionStorage.setItem('crs_session', JSON.stringify(res.data.user));
      IS_ONLINE = true;
      return { ok:true, user:res.data.user };
    }
    // Fallback to local
    const u = CRS.users.find(u => u.email === email && u.password === password);
    if (u) {
      CRS.currentUser = u;
      sessionStorage.setItem('crs_session', JSON.stringify(u));
      return { ok:true, user:u };
    }
    return { ok:false, msg: res.msg || 'Invalid credentials' };
  },

  async register(data) {
    const res = await API.post('/auth/register', data);
    if (res.ok) {
      localStorage.setItem('crs_token', res.data.token);
      CRS.currentUser = res.data.user;
      sessionStorage.setItem('crs_session', JSON.stringify(res.data.user));
      IS_ONLINE = true;
      return { ok:true, user:res.data.user };
    }
    if (res.offline) {
      if (CRS.users.find(u => u.email === data.email)) return { ok:false, msg:'Email already registered.' };
      const u = { ...data, id:Date.now(), role:'user', joined:new Date().toISOString() };
      CRS.users.push(u); CRS.save();
      CRS.currentUser = u;
      sessionStorage.setItem('crs_session', JSON.stringify(u));
      return { ok:true, user:u };
    }
    return { ok:false, msg: res.msg || 'Registration failed' };
  },

  logout() {
    CRS.currentUser = null;
    localStorage.removeItem('crs_token');
    sessionStorage.removeItem('crs_session');
    window.location.href = 'index.html';
  },

  restore() {
    const s = sessionStorage.getItem('crs_session');
    if (s) { CRS.currentUser = JSON.parse(s); return true; }
    return false;
  }
};
Auth.restore();

// ── Check backend status ─────────────────────────────────────
async function checkBackend() {
  try {
    const r = await fetch(API_BASE + '/health', {signal: AbortSignal.timeout(2000)});
    IS_ONLINE = r.ok;
  } catch { IS_ONLINE = false; }
  const badge = document.getElementById('backendBadge');
  if (badge) {
    badge.textContent = IS_ONLINE ? '🟢 API Connected' : '🔴 Offline Mode';
    badge.style.color = IS_ONLINE ? 'var(--success)' : 'var(--warning)';
  }
  return IS_ONLINE;
}

// ── Toast ────────────────────────────────────────────────────
const Toast = {
  show(title, msg, type='info') {
    const icons = {success:'✅',error:'❌',warning:'⚠️',info:'ℹ️'};
    const container = document.getElementById('toastContainer') || (() => {
      const c=document.createElement('div'); c.id='toastContainer'; c.className='toast-container'; document.body.appendChild(c); return c;
    })();
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type]}</span><div class="toast-body"><div class="toast-title">${title}</div><div class="toast-msg">${msg}</div></div><button class="toast-close" onclick="this.parentElement.remove()">✕</button>`;
    container.appendChild(toast);
    setTimeout(()=>toast.classList.add('show'),10);
    setTimeout(()=>{toast.classList.remove('show');setTimeout(()=>toast.remove(),350);},4000);
  }
};

// ── Navbar ───────────────────────────────────────────────────
function initNavbar() {
  const nav = document.querySelector('.navbar');
  if (!nav) return;
  window.addEventListener('scroll',()=>nav.classList.toggle('scrolled',window.scrollY>50));
  updateNavAuth();

  // Mobile hamburger
  const toggle = document.getElementById('navToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  if (toggle && mobileMenu) {
    toggle.addEventListener('click',()=>{
      mobileMenu.classList.toggle('open');
      toggle.textContent = mobileMenu.classList.contains('open') ? '✕' : '☰';
    });
    document.addEventListener('click',e=>{
      if(!e.target.closest('.navbar')) mobileMenu.classList.remove('open');
    });
  }
}

function updateNavAuth() {
  const loginBtn    = document.getElementById('navLoginBtn');
  const registerBtn = document.getElementById('navRegisterBtn');
  const userMenu    = document.getElementById('navUserMenu');
  const navAvatar   = document.getElementById('navAvatar');
  if (CRS.currentUser) {
    loginBtn?.classList.add('hidden');
    registerBtn?.classList.add('hidden');
    userMenu?.classList.remove('hidden');
    if (navAvatar) navAvatar.textContent = CRS.currentUser.name.charAt(0).toUpperCase();
  } else {
    loginBtn?.classList.remove('hidden');
    registerBtn?.classList.remove('hidden');
    userMenu?.classList.add('hidden');
  }
}

// ── Animations ───────────────────────────────────────────────
function initAnimations() {
  const observer = new IntersectionObserver(entries=>{
    entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('visible'); });
  }, {threshold:0.08, rootMargin:'0px 0px -40px 0px'});
  document.querySelectorAll('.fade-up,.fade-in,.slide-in').forEach(el=>observer.observe(el));
}

// ── Modals ───────────────────────────────────────────────────
function openModal(id)  { const m=document.getElementById(id); if(m){m.classList.add('active');document.body.style.overflow='hidden';} }
function closeModal(id) { const m=document.getElementById(id); if(m){m.classList.remove('active');document.body.style.overflow='';} }
document.addEventListener('click',e=>{ if(e.target.classList.contains('modal-overlay')) closeModal(e.target.id); });

// ── Tabs ─────────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tabs').forEach(tabsEl=>{
    const tabs=tabsEl.querySelectorAll('.tab');
    tabs.forEach((tab,i)=>{
      tab.addEventListener('click',()=>{
        tabs.forEach(t=>t.classList.remove('active'));
        tab.classList.add('active');
        const contents=document.querySelectorAll(`[data-tab-group="${tabsEl.dataset.group}"]`);
        contents.forEach((c,j)=>c.classList.toggle('active',j===i));
      });
    });
  });
}

// ── Star Ratings ─────────────────────────────────────────────
function initStarRatings() {
  document.querySelectorAll('.star-rating-input').forEach(wrap=>{
    const stars=wrap.querySelectorAll('.star'), input=wrap.querySelector('input[type="hidden"]');
    stars.forEach((star,i)=>{
      star.addEventListener('click',()=>{ if(input)input.value=i+1; stars.forEach((s,j)=>s.classList.toggle('filled',j<=i)); });
      star.addEventListener('mouseover',()=>stars.forEach((s,j)=>s.classList.toggle('filled',j<=i)));
      star.addEventListener('mouseout',()=>{ const v=input?+input.value:0; stars.forEach((s,j)=>s.classList.toggle('filled',j<v)); });
    });
  });
}

// ── Utilities ────────────────────────────────────────────────
function filterColors(colors, {search='',category='All',available=false,sortBy='popularity'}={}) {
  let r=[...colors];
  if(search) r=r.filter(c=>c.name.toLowerCase().includes(search.toLowerCase())||c.hex.toLowerCase().includes(search.toLowerCase())||c.category.toLowerCase().includes(search.toLowerCase()));
  if(category!=='All') r=r.filter(c=>c.category===category);
  if(available) r=r.filter(c=>c.available);
  r.sort((a,b)=>{
    if(sortBy==='popularity') return b.popularity-a.popularity;
    if(sortBy==='price-asc')  return a.price-b.price;
    if(sortBy==='price-desc') return b.price-a.price;
    if(sortBy==='name')       return a.name.localeCompare(b.name);
    return 0;
  });
  return r;
}

function renderStars(rating, max=5) {
  let html='<div class="stars">';
  for(let i=1;i<=max;i++) html+=`<span class="star ${i<=Math.round(rating)?'filled':''}">★</span>`;
  return html+'</div>';
}

function formatDate(d) { return new Date(d).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}); }
function formatCurrency(n) { return '₹'+Number(n).toLocaleString('en-IN'); }
function genId() { return Date.now()+Math.random().toString(36).substr(2,5); }

document.addEventListener('DOMContentLoaded',()=>{
  initNavbar();
  initAnimations();
  initTabs();
  initStarRatings();
  checkBackend();
});
