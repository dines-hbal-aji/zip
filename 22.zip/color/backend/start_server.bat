@echo off
title ColorHub Backend Server
color 0A
echo.
echo  ========================================
echo   ColorHub Color Reservation System
echo   Backend API Server (Flask + SQLite)
echo  ========================================
echo.
echo  Starting server on http://localhost:5000
echo  Admin: admin@colorhub.com / admin123
echo.
cd /d "%~dp0"
python app.py
pause
