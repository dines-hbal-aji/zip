# ============================================================
#  ColorHub Backend - Flask + SQLite
#  Author: 23COS212 K.Dinesh Balaji
#  Run: python app.py
# ============================================================

from flask import Flask, request, jsonify, g
from flask_cors import CORS
from flask_jwt_extended import (JWTManager, create_access_token,
                                jwt_required, get_jwt_identity, get_jwt)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta, date
import os, json, random, string

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# ── Config ──────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.config['SQLALCHEMY_DATABASE_URI']  = f'sqlite:///{os.path.join(BASE_DIR, "colorhub.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY']           = 'colorhub-secret-2025-dinesh'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=7)

db  = SQLAlchemy(app)
jwt = JWTManager(app)

# ── Models ───────────────────────────────────────────────────

class User(db.Model):
    __tablename__ = 'users'
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(150), unique=True, nullable=False)
    password   = db.Column(db.String(200), nullable=False)
    role       = db.Column(db.String(20), default='user')
    phone      = db.Column(db.String(20), default='')
    bio        = db.Column(db.Text, default='')
    joined     = db.Column(db.DateTime, default=datetime.utcnow)
    reservations = db.relationship('Reservation', backref='user', lazy=True)
    reviews      = db.relationship('Review', backref='user', lazy=True)
    combinations = db.relationship('ColorCombination', backref='user', lazy=True)

    def to_dict(self, public=False):
        d = {'id':self.id,'name':self.name,'email':self.email,
             'role':self.role,'phone':self.phone,'bio':self.bio,
             'joined':self.joined.isoformat()}
        if public: d.pop('email', None)
        return d


class Color(db.Model):
    __tablename__ = 'colors'
    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(100), nullable=False)
    hex_code    = db.Column(db.String(10), nullable=False)
    rgb         = db.Column(db.String(30), default='')
    category    = db.Column(db.String(50), nullable=False)
    stock       = db.Column(db.Integer, default=20)
    is_available= db.Column(db.Boolean, default=True)
    popularity  = db.Column(db.Integer, default=50)
    price       = db.Column(db.Float, default=750)
    description = db.Column(db.Text, default='')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        avg_rating = 0
        if self.reviews:
            avg_rating = round(sum(r.rating for r in self.reviews) / len(self.reviews), 1)
        return {
            'id':self.id,'name':self.name,'hex':self.hex_code,'rgb':self.rgb,
            'category':self.category,'stock':self.stock,
            'available':self.is_available,'popularity':self.popularity,
            'price':self.price,'description':self.description,
            'avgRating':avg_rating,'reviewCount':len(self.reviews),
            'reservationCount': len([r for r in self.reservations if r.status != 'cancelled'])
        }


class Reservation(db.Model):
    __tablename__ = 'reservations'
    id             = db.Column(db.String(30), primary_key=True)
    user_id        = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    color_id       = db.Column(db.Integer, db.ForeignKey('colors.id'), nullable=False)
    start_date     = db.Column(db.Date, nullable=False)
    end_date       = db.Column(db.Date, nullable=False)
    quantity       = db.Column(db.Integer, default=1)
    total          = db.Column(db.Float, default=0)
    payment_method = db.Column(db.String(30), default='upi')
    txn_id         = db.Column(db.String(50), default='')
    status         = db.Column(db.String(20), default='confirmed')
    notes          = db.Column(db.Text, default='')
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)
    color          = db.relationship('Color', backref='reservations', lazy=True)

    def to_dict(self):
        c = self.color
        u = self.user
        return {
            'id':self.id,'userId':self.user_id,'colorId':self.color_id,
            'colorName': c.name if c else '','colorHex': c.hex_code if c else '',
            'userName': u.name if u else '',
            'startDate':self.start_date.isoformat(),'endDate':self.end_date.isoformat(),
            'quantity':self.quantity,'total':self.total,
            'paymentMethod':self.payment_method,'txnId':self.txn_id,
            'status':self.status,'notes':self.notes,
            'createdAt':self.created_at.isoformat()
        }


class Review(db.Model):
    __tablename__ = 'reviews'
    id             = db.Column(db.String(30), primary_key=True)
    user_id        = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    color_id       = db.Column(db.Integer, db.ForeignKey('colors.id'), nullable=False)
    reservation_id = db.Column(db.String(30), db.ForeignKey('reservations.id'), nullable=False)
    rating         = db.Column(db.Integer, nullable=False)
    comment        = db.Column(db.Text, nullable=False)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)
    color          = db.relationship('Color', backref='reviews')

    def to_dict(self):
        u = self.user
        c = self.color
        return {
            'id':self.id,'userId':self.user_id,'colorId':self.color_id,
            'reservationId':self.reservation_id,'rating':self.rating,
            'comment':self.comment,'createdAt':self.created_at.isoformat(),
            'userName': u.name if u else '','colorName': c.name if c else '',
            'colorHex': c.hex_code if c else ''
        }


class ColorCombination(db.Model):
    __tablename__ = 'color_combinations'
    id          = db.Column(db.String(30), primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    name        = db.Column(db.String(100), nullable=False)
    colors      = db.Column(db.Text, nullable=False)   # JSON array of hex codes & names
    combo_type  = db.Column(db.String(30), default='custom')  # complementary/analogous/triadic/custom
    is_public   = db.Column(db.Boolean, default=True)
    likes       = db.Column(db.Integer, default=0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        u = self.user
        return {
            'id':self.id,'userId':self.user_id,'name':self.name,
            'colors':json.loads(self.colors),'comboType':self.combo_type,
            'isPublic':self.is_public,'likes':self.likes,
            'createdAt':self.created_at.isoformat(),
            'userName': u.name if u else 'Anonymous'
        }


# ── Helpers ──────────────────────────────────────────────────

def gen_id(prefix=''):
    return prefix + ''.join(random.choices(string.ascii_letters + string.digits, k=12))

def check_conflict(color_id, start_date, end_date, exclude_id=None):
    q = Reservation.query.filter(
        Reservation.color_id == color_id,
        Reservation.status   != 'cancelled'
    )
    if exclude_id:
        q = q.filter(Reservation.id != exclude_id)
    for r in q.all():
        if not (end_date <= r.start_date or start_date >= r.end_date):
            return True
    return False

def hex_to_rgb(hex_code):
    h = hex_code.lstrip('#')
    if len(h) != 6: return (0,0,0)
    return tuple(int(h[i:i+2], 16) for i in (0,2,4))

def rgb_to_hex(r, g, b):
    return '#{:02X}{:02X}{:02X}'.format(max(0,min(255,r)), max(0,min(255,g)), max(0,min(255,b)))

def get_complementary(hex_code):
    r,g,b = hex_to_rgb(hex_code)
    return rgb_to_hex(255-r, 255-g, 255-b)

def get_analogous(hex_code):
    r,g,b = hex_to_rgb(hex_code)
    # Rotate hue ±30°
    import colorsys
    h,s,v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    results = []
    for offset in [-1/12, 1/12]:
        h2 = (h + offset) % 1.0
        r2,g2,b2 = colorsys.hsv_to_rgb(h2, s, v)
        results.append(rgb_to_hex(int(r2*255), int(g2*255), int(b2*255)))
    return results

def get_triadic(hex_code):
    r,g,b = hex_to_rgb(hex_code)
    import colorsys
    h,s,v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    results = []
    for offset in [1/3, 2/3]:
        h2 = (h + offset) % 1.0
        r2,g2,b2 = colorsys.hsv_to_rgb(h2, s, v)
        results.append(rgb_to_hex(int(r2*255), int(g2*255), int(b2*255)))
    return results

def get_split_complementary(hex_code):
    r,g,b = hex_to_rgb(hex_code)
    import colorsys
    h,s,v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    results = []
    for offset in [5/12, 7/12]:
        h2 = (h + offset) % 1.0
        r2,g2,b2 = colorsys.hsv_to_rgb(h2, s, v)
        results.append(rgb_to_hex(int(r2*255), int(g2*255), int(b2*255)))
    return results

def get_tetradic(hex_code):
    r,g,b = hex_to_rgb(hex_code)
    import colorsys
    h,s,v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    results = []
    for offset in [1/4, 1/2, 3/4]:
        h2 = (h + offset) % 1.0
        r2,g2,b2 = colorsys.hsv_to_rgb(h2, s, v)
        results.append(rgb_to_hex(int(r2*255), int(g2*255), int(b2*255)))
    return results

def get_monochromatic(hex_code):
    r,g,b = hex_to_rgb(hex_code)
    import colorsys
    h,s,v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    results = []
    for v2 in [0.3, 0.55, 0.8]:
        r2,g2,b2 = colorsys.hsv_to_rgb(h, s, v2)
        results.append(rgb_to_hex(int(r2*255), int(g2*255), int(b2*255)))
    return results


def ok(data=None, msg='', code=200):
    return jsonify({'ok':True,'msg':msg,'data':data}), code

def err(msg, code=400):
    return jsonify({'ok':False,'msg':msg}), code

def current_user():
    uid = get_jwt_identity()
    return User.query.get(uid)

def admin_required(fn):
    from functools import wraps
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        u = current_user()
        if not u or u.role != 'admin':
            return err('Admin access required', 403)
        return fn(*args, **kwargs)
    return wrapper


# ── Auth Routes ──────────────────────────────────────────────

@app.route('/api/auth/register', methods=['POST'])
def register():
    d = request.get_json()
    if not d: return err('No data provided')
    name  = (d.get('name') or '').strip()
    email = (d.get('email') or '').strip().lower()
    pwd   = d.get('password', '')
    if not name or not email or not pwd:
        return err('Name, email and password are required')
    if len(pwd) < 6:
        return err('Password must be at least 6 characters')
    if User.query.filter_by(email=email).first():
        return err('Email already registered')
    u = User(name=name, email=email,
             password=generate_password_hash(pwd),
             phone=d.get('phone',''), role='user')
    db.session.add(u)
    db.session.commit()
    token = create_access_token(identity=u.id)
    return ok({'token':token,'user':u.to_dict()}, 'Account created!', 201)


@app.route('/api/auth/login', methods=['POST'])
def login():
    d = request.get_json()
    if not d: return err('No data provided')
    email = (d.get('email') or '').strip().lower()
    pwd   = d.get('password', '')
    u = User.query.filter_by(email=email).first()
    if not u or not check_password_hash(u.password, pwd):
        return err('Invalid email or password', 401)
    token = create_access_token(identity=u.id)
    return ok({'token':token,'user':u.to_dict()}, 'Logged in!')


@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def me():
    u = current_user()
    if not u: return err('User not found', 404)
    return ok(u.to_dict())


@app.route('/api/auth/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    u = current_user()
    if not u: return err('Not found', 404)
    d = request.get_json()
    if d.get('name'): u.name = d['name'].strip()
    if d.get('phone') is not None: u.phone = d['phone']
    if d.get('bio') is not None: u.bio = d['bio']
    if d.get('password') and len(d['password']) >= 6:
        u.password = generate_password_hash(d['password'])
    db.session.commit()
    return ok(u.to_dict(), 'Profile updated')


# ── Color Routes ─────────────────────────────────────────────

@app.route('/api/colors', methods=['GET'])
def get_colors():
    q = Color.query
    search   = request.args.get('search','')
    category = request.args.get('category','')
    avail    = request.args.get('available','')
    sort     = request.args.get('sort','popularity')
    max_price= request.args.get('maxPrice', type=float)

    if search:
        q = q.filter(
            db.or_(Color.name.ilike(f'%{search}%'),
                   Color.hex_code.ilike(f'%{search}%'),
                   Color.category.ilike(f'%{search}%'))
        )
    if category and category != 'All':
        q = q.filter_by(category=category)
    if avail == 'true':
        q = q.filter_by(is_available=True)
    if max_price:
        q = q.filter(Color.price <= max_price)

    colors = q.all()
    if sort == 'popularity': colors.sort(key=lambda c: -c.popularity)
    elif sort == 'price-asc': colors.sort(key=lambda c: c.price)
    elif sort == 'price-desc': colors.sort(key=lambda c: -c.price)
    elif sort == 'name': colors.sort(key=lambda c: c.name)

    return ok([c.to_dict() for c in colors])


@app.route('/api/colors/<int:cid>', methods=['GET'])
def get_color(cid):
    c = Color.query.get_or_404(cid)
    return ok(c.to_dict())


@app.route('/api/colors', methods=['POST'])
@admin_required
def add_color():
    d = request.get_json()
    r,g,b = hex_to_rgb(d.get('hex','#000000'))
    c = Color(
        name=d['name'], hex_code=d['hex'].upper(),
        rgb=f'{r},{g},{b}', category=d.get('category','Warm'),
        stock=int(d.get('stock',20)), price=float(d.get('price',750)),
        description=d.get('description',''), popularity=50
    )
    db.session.add(c); db.session.commit()
    return ok(c.to_dict(), 'Color added', 201)


@app.route('/api/colors/<int:cid>', methods=['PUT'])
@admin_required
def update_color(cid):
    c = Color.query.get_or_404(cid)
    d = request.get_json()
    for field in ['name','category','description']:
        if field in d: setattr(c, field, d[field])
    if 'hex' in d:
        c.hex_code = d['hex'].upper()
        r,g,b = hex_to_rgb(d['hex'])
        c.rgb = f'{r},{g},{b}'
    if 'stock' in d: c.stock = int(d['stock'])
    if 'price' in d: c.price = float(d['price'])
    if 'available' in d: c.is_available = bool(d['available'])
    db.session.commit()
    return ok(c.to_dict(), 'Updated')


@app.route('/api/colors/<int:cid>', methods=['DELETE'])
@admin_required
def delete_color(cid):
    c = Color.query.get_or_404(cid)
    db.session.delete(c); db.session.commit()
    return ok(msg='Color deleted')


@app.route('/api/colors/<int:cid>/combinations', methods=['GET'])
def get_color_combos(cid):
    c = Color.query.get_or_404(cid)
    hex_code = c.hex_code

    comp   = get_complementary(hex_code)
    anal   = get_analogous(hex_code)
    triad  = get_triadic(hex_code)
    split  = get_split_complementary(hex_code)
    tetra  = get_tetradic(hex_code)
    mono   = get_monochromatic(hex_code)

    return ok({
        'base': {'hex': hex_code, 'name': c.name},
        'complementary': [{'hex': comp, 'name': 'Complement'}],
        'analogous': [{'hex': h, 'name': f'Analogous {i+1}'} for i,h in enumerate(anal)],
        'triadic': [{'hex': h, 'name': f'Triadic {i+1}'} for i,h in enumerate(triad)],
        'splitComplementary': [{'hex': h, 'name': f'Split {i+1}'} for i,h in enumerate(split)],
        'tetradic': [{'hex': h, 'name': f'Tetradic {i+1}'} for i,h in enumerate(tetra)],
        'monochromatic': [{'hex': h, 'name': f'Mono {i+1}'} for i,h in enumerate(mono)],
    })


# ── Reservation Routes ───────────────────────────────────────

@app.route('/api/reservations', methods=['GET'])
@jwt_required()
def get_reservations():
    u = current_user()
    if u.role == 'admin':
        reservations = Reservation.query.order_by(Reservation.created_at.desc()).all()
    else:
        reservations = Reservation.query.filter_by(user_id=u.id)\
                           .order_by(Reservation.created_at.desc()).all()
    return ok([r.to_dict() for r in reservations])


@app.route('/api/reservations', methods=['POST'])
@jwt_required()
def create_reservation():
    u  = current_user()
    d  = request.get_json()
    try:
        s = date.fromisoformat(d['startDate'])
        e = date.fromisoformat(d['endDate'])
    except (KeyError, ValueError):
        return err('Invalid dates')
    if e <= s:
        return err('End date must be after start date')

    color_id = int(d.get('colorId', 0))
    c = Color.query.get(color_id)
    if not c: return err('Color not found', 404)
    if not c.is_available: return err('Color is not available for reservation')

    if check_conflict(color_id, s, e):
        return err('Color already reserved for these dates. Please choose different dates.')

    qty   = int(d.get('quantity', 1))
    days  = (e - s).days
    total = c.price * qty * days
    txn   = 'TXN' + gen_id()

    r = Reservation(
        id=gen_id('RES'), user_id=u.id, color_id=color_id,
        start_date=s, end_date=e, quantity=qty, total=total,
        payment_method=d.get('paymentMethod','upi'),
        txn_id=txn, status='confirmed',
        notes=d.get('notes','')
    )
    db.session.add(r); db.session.commit()
    return ok(r.to_dict(), 'Reservation confirmed!', 201)


@app.route('/api/reservations/<string:rid>', methods=['GET'])
@jwt_required()
def get_reservation(rid):
    r = Reservation.query.get_or_404(rid)
    u = current_user()
    if u.role != 'admin' and r.user_id != u.id:
        return err('Access denied', 403)
    return ok(r.to_dict())


@app.route('/api/reservations/<string:rid>/cancel', methods=['PUT'])
@jwt_required()
def cancel_reservation(rid):
    r = Reservation.query.get_or_404(rid)
    u = current_user()
    if u.role != 'admin' and r.user_id != u.id:
        return err('Access denied', 403)
    r.status = 'cancelled'
    db.session.commit()
    return ok(r.to_dict(), 'Reservation cancelled')


@app.route('/api/reservations/<int:color_id>/availability', methods=['GET'])
def check_availability(color_id):
    try:
        s = date.fromisoformat(request.args.get('start',''))
        e = date.fromisoformat(request.args.get('end',''))
    except ValueError:
        return err('Invalid date format. Use YYYY-MM-DD')
    conflict = check_conflict(color_id, s, e)
    reserved_dates = []
    for res in Reservation.query.filter(
        Reservation.color_id == color_id,
        Reservation.status   != 'cancelled'
    ).all():
        reserved_dates.append({'start':res.start_date.isoformat(),'end':res.end_date.isoformat()})
    return ok({'available': not conflict, 'reservedDates': reserved_dates})


# ── Review Routes ────────────────────────────────────────────

@app.route('/api/reviews', methods=['GET'])
def get_reviews():
    color_id = request.args.get('colorId', type=int)
    q = Review.query
    if color_id: q = q.filter_by(color_id=color_id)
    reviews = q.order_by(Review.created_at.desc()).all()
    return ok([r.to_dict() for r in reviews])


@app.route('/api/reviews', methods=['POST'])
@jwt_required()
def add_review():
    u  = current_user()
    d  = request.get_json()
    res_id   = d.get('reservationId')
    color_id = d.get('colorId')
    rating   = int(d.get('rating', 0))
    comment  = (d.get('comment') or '').strip()

    if not res_id or not color_id or not rating or not comment:
        return err('Reservation, color, rating and comment are required')
    if rating < 1 or rating > 5:
        return err('Rating must be 1-5')

    res = Reservation.query.get(res_id)
    if not res: return err('Reservation not found', 404)
    if res.user_id != u.id: return err('Access denied', 403)

    if Review.query.filter_by(reservation_id=res_id, user_id=u.id).first():
        return err('You have already reviewed this reservation')

    rv = Review(id=gen_id('REV'), user_id=u.id, color_id=int(color_id),
                reservation_id=res_id, rating=rating, comment=comment)
    db.session.add(rv); db.session.commit()
    return ok(rv.to_dict(), 'Review submitted!', 201)


@app.route('/api/reviews/<string:rid>', methods=['DELETE'])
@admin_required
def delete_review(rid):
    rv = Review.query.get_or_404(rid)
    db.session.delete(rv); db.session.commit()
    return ok(msg='Review deleted')


# ── Color Combinations Routes ────────────────────────────────

@app.route('/api/combinations', methods=['GET'])
def get_combinations():
    combos = ColorCombination.query.filter_by(is_public=True)\
                 .order_by(ColorCombination.likes.desc()).all()
    return ok([c.to_dict() for c in combos])


@app.route('/api/combinations/my', methods=['GET'])
@jwt_required()
def my_combinations():
    u = current_user()
    combos = ColorCombination.query.filter_by(user_id=u.id)\
                 .order_by(ColorCombination.created_at.desc()).all()
    return ok([c.to_dict() for c in combos])


@app.route('/api/combinations', methods=['POST'])
@jwt_required(optional=True)
def save_combination():
    uid = get_jwt_identity()
    d   = request.get_json()
    name   = (d.get('name') or '').strip() or 'My Palette'
    colors = d.get('colors', [])
    if len(colors) < 2: return err('At least 2 colors required')
    combo = ColorCombination(
        id=gen_id('CB'), user_id=uid, name=name,
        colors=json.dumps(colors), combo_type=d.get('comboType','custom'),
        is_public=d.get('isPublic', True)
    )
    db.session.add(combo); db.session.commit()
    return ok(combo.to_dict(), 'Combination saved!', 201)


@app.route('/api/combinations/<string:cid>/like', methods=['POST'])
def like_combination(cid):
    c = ColorCombination.query.get_or_404(cid)
    c.likes += 1; db.session.commit()
    return ok({'likes': c.likes})


@app.route('/api/combinations/<string:cid>', methods=['DELETE'])
@jwt_required()
def delete_combination(cid):
    c  = ColorCombination.query.get_or_404(cid)
    u  = current_user()
    if u.role != 'admin' and c.user_id != u.id:
        return err('Access denied', 403)
    db.session.delete(c); db.session.commit()
    return ok(msg='Combination deleted')


@app.route('/api/combinations/generate', methods=['POST'])
def generate_combinations():
    d        = request.get_json()
    hex_code = (d.get('hex') or '#FF0000').upper()
    mode     = d.get('mode', 'all')

    comp  = get_complementary(hex_code)
    anal  = get_analogous(hex_code)
    triad = get_triadic(hex_code)
    split = get_split_complementary(hex_code)
    tetra = get_tetradic(hex_code)
    mono  = get_monochromatic(hex_code)

    result = {
        'input': hex_code,
        'complementary': {'name':'Complementary','colors':[hex_code, comp]},
        'analogous': {'name':'Analogous','colors':[anal[0], hex_code, anal[1]]},
        'triadic': {'name':'Triadic','colors':[hex_code]+triad},
        'splitComplementary': {'name':'Split Complementary','colors':[hex_code]+split},
        'tetradic': {'name':'Tetradic','colors':[hex_code]+tetra},
        'monochromatic': {'name':'Monochromatic','colors':mono+[hex_code]},
    }
    return ok(result)


# ── Admin Routes ─────────────────────────────────────────────

@app.route('/api/admin/stats', methods=['GET'])
@admin_required
def admin_stats():
    total_revenue = sum(r.total for r in Reservation.query.filter_by(status='confirmed').all())
    return ok({
        'totalColors':       Color.query.count(),
        'totalReservations': Reservation.query.count(),
        'confirmedRes':      Reservation.query.filter_by(status='confirmed').count(),
        'cancelledRes':      Reservation.query.filter_by(status='cancelled').count(),
        'totalRevenue':      round(total_revenue, 2),
        'totalUsers':        User.query.count(),
        'totalReviews':      Review.query.count(),
        'totalCombinations': ColorCombination.query.count(),
    })


@app.route('/api/admin/users', methods=['GET'])
@admin_required
def admin_users():
    users = User.query.order_by(User.joined.desc()).all()
    result = []
    for u in users:
        d = u.to_dict()
        d['reservationCount'] = len(u.reservations)
        result.append(d)
    return ok(result)


@app.route('/api/admin/users/<int:uid>', methods=['PUT'])
@admin_required
def admin_update_user(uid):
    u  = User.query.get_or_404(uid)
    d  = request.get_json()
    me = current_user()
    if 'role' in d and u.id != me.id:
        u.role = d['role']
    db.session.commit()
    return ok(u.to_dict(), 'User updated')


@app.route('/api/admin/users/<int:uid>', methods=['DELETE'])
@admin_required
def admin_delete_user(uid):
    me = current_user()
    if uid == me.id: return err('Cannot delete yourself', 400)
    u = User.query.get_or_404(uid)
    db.session.delete(u); db.session.commit()
    return ok(msg='User deleted')


@app.route('/api/admin/reviews', methods=['GET'])
@admin_required
def admin_reviews():
    reviews = Review.query.order_by(Review.created_at.desc()).all()
    return ok([r.to_dict() for r in reviews])


# ── Seed Data ────────────────────────────────────────────────

SEED_COLORS = [
    ('Crimson Sunset','#DC143C','220,20,60','Warm',15,850,'A rich passionate crimson.'),
    ('Ocean Depth','#006994','0,105,148','Cool',20,720,'Deep oceanic blue.'),
    ('Forest Canopy','#228B22','34,139,34','Nature',18,680,'Lush forest green.'),
    ('Royal Amethyst','#9B59B6','155,89,182','Luxury',12,1200,'Majestic purple.'),
    ('Golden Harvest','#F0A500','240,165,0','Warm',25,750,'Warm golden yellow.'),
    ('Coral Kiss','#FF6B6B','255,107,107','Warm',10,890,'Vibrant coral.'),
    ('Midnight Navy','#1B2A4A','27,42,74','Cool',30,640,'Deep navy.'),
    ('Mint Breeze','#98D8C8','152,216,200','Cool',22,590,'Refreshing mint.'),
    ('Burnt Sienna','#E97451','233,116,81','Warm',16,780,'Earthy terracotta.'),
    ('Electric Teal','#00CED1','0,206,209','Cool',8,1050,'Vivid teal.'),
    ('Lavender Dreams','#B57BEE','181,123,238','Luxury',14,950,'Soft lavender.'),
    ('Charcoal Storm','#36454F','54,69,79','Neutral',35,520,'Sophisticated charcoal.'),
    ('Tangerine Bliss','#FF8C00','255,140,0','Warm',20,720,'Vivid orange.'),
    ('Arctic White','#F0F4F8','240,244,248','Neutral',50,450,'Clean crisp white.'),
    ('Deep Espresso','#3B1F10','59,31,16','Warm',28,580,'Rich coffee-brown.'),
    ('Hot Magenta','#FF1493','255,20,147','Luxury',6,1350,'Bold magenta.'),
    ('Sage Whisper','#87A96B','135,169,107','Nature',24,660,'Muted sage green.'),
    ('Cobalt Dream','#0047AB','0,71,171','Cool',19,810,'Bold cobalt.'),
    ('Rose Gold','#B76E79','183,110,121','Luxury',11,1150,'Elegant rose gold.'),
    ('Lime Zest','#BEF264','190,242,100','Nature',17,620,'Energetic lime.'),
    ('Slate Blue','#6A5ACD','106,90,205','Cool',13,880,'Rich slate blue.'),
    ('Peach Fuzz','#FFCBA4','255,203,164','Warm',21,560,'Soft peach.'),
    ('Emerald Isle','#009473','0,148,115','Nature',15,740,'Deep emerald green.'),
    ('Storm Grey','#708090','112,128,144','Neutral',40,490,'Balanced storm grey.'),
    ('Vivid Violet','#7F00FF','127,0,255','Luxury',9,1100,'Electric violet.'),
    ('Cherry Blossom','#FFB7C5','255,183,197','Warm',26,610,'Soft cherry pink.'),
    ('Copper Glow','#B87333','184,115,51','Warm',14,830,'Warm copper tone.'),
    ('Sky Clarity','#87CEEB','135,206,235','Cool',30,520,'Light sky blue.'),
    ('Jungle Green','#29AB87','41,171,135','Nature',17,690,'Lush jungle.'),
    ('Merlot Red','#73343A','115,52,58','Warm',10,920,'Deep wine red.'),
]

def seed_db():
    with app.app_context():
        db.create_all()
        # Admin user
        if not User.query.filter_by(email='admin@colorhub.com').first():
            admin = User(name='Admin', email='admin@colorhub.com',
                         password=generate_password_hash('admin123'),
                         role='admin', phone='9876543210')
            db.session.add(admin)
        # Colors
        if Color.query.count() == 0:
            for i,(name,hex,rgb,cat,stock,price,desc) in enumerate(SEED_COLORS):
                r = Color(name=name,hex_code=hex,rgb=rgb,category=cat,
                          stock=stock,price=price,description=desc,
                          popularity=random.randint(55,98))
                db.session.add(r)
        db.session.commit()
        print(f'✅  Database seeded — {Color.query.count()} colors, {User.query.count()} users')


# ── Health Check ─────────────────────────────────────────────

@app.route('/api/health', methods=['GET'])
def health():
    return ok({'status':'ok','version':'1.0','colors':Color.query.count(),
               'users':User.query.count(),'reservations':Reservation.query.count()})

@app.route('/', methods=['GET'])
def home():
    return jsonify({'message':'ColorHub API is running! 🎨','docs':'/api/health'})


if __name__ == '__main__':
    seed_db()
    print('\n🎨  ColorHub API starting on http://localhost:5000')
    print('   Admin: admin@colorhub.com / admin123\n')
    app.run(debug=True, host='0.0.0.0', port=5000)
